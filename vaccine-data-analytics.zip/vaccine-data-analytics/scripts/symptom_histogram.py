#!/usr/bin/env python3
"""
Symptom Histogram Generator

Creates symptom frequency histograms for each vaccine batch code.
Outputs one JSON file per batch in the format expected by the frontend.

Usage:
    python symptom_histogram.py <vaers_symptoms.csv> <vaers_vax.csv> <output_dir>

Output: One JSON file per batch in output_dir/
"""

import pandas as pd
import sys
import json
from pathlib import Path
from collections import Counter


def load_and_prepare_data(symptoms_file: str, vax_file: str) -> pd.DataFrame:
    """
    Load VAERS symptoms and vaccine data, merge, and prepare for analysis.

    Args:
        symptoms_file: Path to VAERSSYMPTOMS.csv
        vax_file: Path to VAERSVAX.csv

    Returns:
        Merged DataFrame with symptoms and batch codes
    """
    print(f"📂 Loading symptoms from {symptoms_file}...")
    symptoms = pd.read_csv(symptoms_file, encoding='iso-8859-1', low_memory=False)

    print(f"📂 Loading vaccine data from {vax_file}...")
    vax = pd.read_csv(vax_file, encoding='iso-8859-1', low_memory=False)

    # Filter to COVID-19 vaccines
    if 'VAX_TYPE' in vax.columns:
        vax = vax[vax['VAX_TYPE'] == 'COVID19']

    # Normalize batch codes
    vax['VAX_LOT'] = vax['VAX_LOT'].str.upper().str.strip()

    # Merge
    print("🔗 Merging symptoms with batch codes...")
    merged = symptoms.merge(
        vax[['VAERS_ID', 'VAX_LOT', 'VAX_MANU']],
        on='VAERS_ID',
        how='inner'
    )

    return merged


def create_symptom_histograms(data: pd.DataFrame) -> dict:
    """
    Create symptom frequency histograms for each batch code.

    Args:
        data: Merged DataFrame with SYMPTOM columns and VAX_LOT

    Returns:
        Dictionary mapping batch code to histogram dict
    """
    # Identify symptom columns
    symptom_cols = [col for col in data.columns if col.startswith('SYMPTOM') and not 'VERSION' in col]

    print(f"📊 Processing {len(symptom_cols)} symptom columns...")

    histograms = {}

    for batch_code in data['VAX_LOT'].unique():
        if pd.isna(batch_code) or batch_code == '':
            continue

        batch_data = data[data['VAX_LOT'] == batch_code]

        # Collect all symptoms for this batch
        all_symptoms = []
        for col in symptom_cols:
            symptoms_in_col = batch_data[col].dropna()
            all_symptoms.extend(symptoms_in_col.tolist())

        # Create frequency histogram
        symptom_counts = Counter(all_symptoms)

        # Get manufacturer
        manu = batch_data['VAX_MANU'].mode()[0] if len(batch_data['VAX_MANU'].mode()) > 0 else 'Unknown'

        histograms[batch_code] = {
            'batchcode': batch_code,
            'Company': manu,
            'Adverse Reaction Reports': len(batch_data),
            'histogram': dict(symptom_counts)
        }

    return histograms


def save_histograms(histograms: dict, output_dir: str):
    """
    Save individual histogram JSON files for each batch code.

    Args:
        histograms: Dictionary mapping batch code to histogram data
        output_dir: Directory to save JSON files
    """
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    print(f"💾 Saving {len(histograms)} histogram files to {output_dir}...")

    saved_count = 0
    for batch_code, histogram_data in histograms.items():
        # Sanitize filename (remove problematic characters)
        safe_filename = batch_code.replace('/', '_').replace(' ', '_')
        safe_filename = ''.join(c for c in safe_filename if c.isalnum() or c in ('_', '-', '.'))

        # Skip if filename is empty after sanitization
        if not safe_filename:
            print(f"⚠️  Skipping batch '{batch_code}' (invalid filename)")
            continue

        file_path = output_path / f"{safe_filename}.json"

        try:
            with open(file_path, 'w') as f:
                json.dump(histogram_data, f, indent=2)
            saved_count += 1
        except Exception as e:
            print(f"❌ Error saving {batch_code}: {e}")

    print(f"✅ Saved {saved_count} histogram files")


def main():
    if len(sys.argv) != 4:
        print("Usage: python symptom_histogram.py <symptoms_csv> <vax_csv> <output_dir>")
        print("\nExample:")
        print("  python symptom_histogram.py VAERSSYMPTOMS.csv VAERSVAX.csv data/histograms/Global/")
        sys.exit(1)

    symptoms_file = sys.argv[1]
    vax_file = sys.argv[2]
    output_dir = sys.argv[3]

    # Load and prepare data
    data = load_and_prepare_data(symptoms_file, vax_file)

    print(f"\n📈 Dataset summary:")
    print(f"   Total reports: {data['VAERS_ID'].nunique():,}")
    print(f"   Unique batches: {data['VAX_LOT'].nunique():,}")

    # Create histograms
    print("\n🔢 Generating symptom histograms...")
    histograms = create_symptom_histograms(data)

    # Save to disk
    print(f"\n💾 Saving to {output_dir}...")
    save_histograms(histograms, output_dir)

    # Print sample
    if histograms:
        sample_batch = list(histograms.keys())[0]
        sample_data = histograms[sample_batch]
        print(f"\n📊 Sample histogram ({sample_batch}):")
        print(f"   Company: {sample_data['Company']}")
        print(f"   Reports: {sample_data['Adverse Reaction Reports']}")
        top_symptoms = sorted(
            sample_data['histogram'].items(),
            key=lambda x: x[1],
            reverse=True
        )[:5]
        print("   Top 5 symptoms:")
        for symptom, count in top_symptoms:
            print(f"     - {symptom}: {count}")


if __name__ == '__main__':
    main()
