#!/usr/bin/env python3
"""
VAERS Data Merger

Merges the three VAERS data files (VAERSDATA, VAERSVAX, VAERSSYMPTOMS)
into a single DataFrame for analysis. Handles normalization and filtering.

Usage:
    python vaers_data_merger.py <data_dir> <output_csv>

Where data_dir contains:
    - VAERSDATA.csv (or 2023VAERSDATA.csv, etc.)
    - VAERSVAX.csv
    - VAERSSYMPTOMS.csv

Output: Single merged CSV file with all data combined
"""

import pandas as pd
import sys
from pathlib import Path
import glob


def find_vaers_files(data_dir: str) -> dict:
    """
    Find VAERS CSV files in directory, handling year prefixes.

    Args:
        data_dir: Directory containing VAERS CSV files

    Returns:
        Dictionary with keys 'data', 'vax', 'symptoms' pointing to file paths
    """
    data_path = Path(data_dir)

    files = {
        'data': None,
        'vax': None,
        'symptoms': None
    }

    # Look for files with various naming patterns
    for file in data_path.glob('*VAERSDATA.csv'):
        files['data'] = file
        break

    for file in data_path.glob('*VAERSVAX.csv'):
        files['vax'] = file
        break

    for file in data_path.glob('*VAERSSYMPTOMS.csv'):
        files['symptoms'] = file
        break

    # Check if all files found
    missing = [k for k, v in files.items() if v is None]
    if missing:
        print(f"❌ Missing VAERS files: {', '.join(missing)}")
        print(f"\nLooked in: {data_path}")
        print("Expected files: *VAERSDATA.csv, *VAERSVAX.csv, *VAERSSYMPTOMS.csv")
        sys.exit(1)

    return files


def normalize_binary_columns(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    """
    Convert Y/N columns to 1/0 integers.

    Args:
        df: DataFrame to modify
        columns: List of column names to normalize

    Returns:
        Modified DataFrame
    """
    for col in columns:
        if col in df.columns:
            df[col] = (df[col] == 'Y').astype(int)

    return df


def merge_vaers_data(files: dict, covid_only: bool = True) -> pd.DataFrame:
    """
    Merge VAERS data files into single DataFrame.

    Args:
        files: Dictionary with paths to VAERS files
        covid_only: If True, filter to COVID-19 vaccines only

    Returns:
        Merged DataFrame
    """
    print(f"📂 Loading VAERSDATA from {files['data']}...")
    vaers_data = pd.read_csv(files['data'], encoding='iso-8859-1', low_memory=False)
    print(f"   Loaded {len(vaers_data):,} records")

    print(f"📂 Loading VAERSVAX from {files['vax']}...")
    vaers_vax = pd.read_csv(files['vax'], encoding='iso-8859-1', low_memory=False)
    print(f"   Loaded {len(vaers_vax):,} records")

    print(f"📂 Loading VAERSSYMPTOMS from {files['symptoms']}...")
    vaers_symptoms = pd.read_csv(files['symptoms'], encoding='iso-8859-1', low_memory=False)
    print(f"   Loaded {len(vaers_symptoms):,} records")

    # Filter to COVID-19 if requested
    if covid_only and 'VAX_TYPE' in vaers_vax.columns:
        print("\n🔍 Filtering to COVID-19 vaccines...")
        vaers_vax = vaers_vax[vaers_vax['VAX_TYPE'] == 'COVID19']
        print(f"   Retained {len(vaers_vax):,} COVID-19 vaccine records")

    # Normalize batch codes
    if 'VAX_LOT' in vaers_vax.columns:
        print("🔧 Normalizing batch codes (uppercase, trimmed)...")
        vaers_vax['VAX_LOT'] = vaers_vax['VAX_LOT'].str.upper().str.strip()

    # Merge VAERSDATA with VAERSVAX
    print("\n🔗 Merging VAERSDATA with VAERSVAX...")
    merged = vaers_data.merge(vaers_vax, on='VAERS_ID', how='inner')
    print(f"   Merged result: {len(merged):,} records")

    # Merge with VAERSSYMPTOMS (left join to preserve records without symptoms)
    print("🔗 Merging with VAERSSYMPTOMS...")
    merged = merged.merge(vaers_symptoms, on='VAERS_ID', how='left')
    print(f"   Final merged result: {len(merged):,} records")

    # Normalize binary columns
    print("\n🔧 Normalizing binary columns (Y/N → 1/0)...")
    binary_cols = ['DIED', 'DISABLE', 'L_THREAT', 'HOSPITAL', 'ER_VISIT', 'RECOVD']
    merged = normalize_binary_columns(merged, binary_cols)

    return merged


def main():
    if len(sys.argv) != 3:
        print("Usage: python vaers_data_merger.py <data_dir> <output_csv>")
        print("\nExample:")
        print("  python vaers_data_merger.py ./src/data/ merged_vaers.csv")
        print("\nExpected files in data_dir:")
        print("  - *VAERSDATA.csv")
        print("  - *VAERSVAX.csv")
        print("  - *VAERSSYMPTOMS.csv")
        sys.exit(1)

    data_dir = sys.argv[1]
    output_file = sys.argv[2]

    # Find VAERS files
    print("🔍 Searching for VAERS files...")
    files = find_vaers_files(data_dir)

    print(f"\n✅ Found VAERS files:")
    print(f"   Data: {files['data'].name}")
    print(f"   Vax: {files['vax'].name}")
    print(f"   Symptoms: {files['symptoms'].name}")

    # Merge data
    print("\n📊 Merging VAERS data...")
    merged = merge_vaers_data(files, covid_only=True)

    # Save result
    print(f"\n💾 Saving merged data to {output_file}...")
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    merged.to_csv(output_file, index=False)

    print(f"✅ Merge complete!")
    print(f"\n📊 Summary:")
    print(f"   Total records: {len(merged):,}")
    print(f"   Unique VAERS IDs: {merged['VAERS_ID'].nunique():,}")
    print(f"   Unique batches: {merged['VAX_LOT'].nunique():,}")
    print(f"   Date range: {merged['VAX_DATE'].min()} to {merged['VAX_DATE'].max()}")
    print(f"   Output file size: {output_path.stat().st_size / 1024 / 1024:.1f} MB")


if __name__ == '__main__':
    main()
