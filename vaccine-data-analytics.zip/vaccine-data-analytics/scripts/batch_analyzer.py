#!/usr/bin/env python3
"""
Batch Code Safety Analyzer

Analyzes VAERS data to calculate safety metrics for vaccine batches.
Produces batch-level aggregations suitable for web display.

Usage:
    python batch_analyzer.py <merged_data.csv> <output.json>

Output format: DataTables orient='split' JSON
"""

import pandas as pd
import sys
import json
from pathlib import Path


def calculate_batch_metrics(data: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate safety metrics aggregated by batch code.

    Args:
        data: Merged VAERS DataFrame with VAX_LOT column

    Returns:
        DataFrame with batch-level metrics
    """
    # Ensure binary fields are properly formatted
    binary_fields = ['DIED', 'DISABLE', 'L_THREAT', 'HOSPITAL']
    for field in binary_fields:
        if field in data.columns:
            # Convert to binary: 'Y' -> 1, else -> 0
            data[field] = (data[field] == 'Y').astype(int)

    # Group by batch code and aggregate
    metrics = data.groupby('VAX_LOT').agg({
        'VAERS_ID': 'count',
        'DIED': 'sum',
        'DISABLE': 'sum',
        'L_THREAT': 'sum',
        'HOSPITAL': 'sum'
    }).rename(columns={
        'VAERS_ID': 'Adverse Reaction Reports',
        'DIED': 'Deaths',
        'DISABLE': 'Disabilities',
        'L_THREAT': 'Life-Threatening Illnesses',
        'HOSPITAL': 'Hospitalizations'
    })

    # Calculate derived metrics
    total_reports = metrics['Adverse Reaction Reports']

    # Severe reports percentage
    severe_count = (
        metrics['Deaths'] +
        metrics['Disabilities'] +
        metrics['Life-Threatening Illnesses'] +
        metrics['Hospitalizations']
    )
    metrics['Severe Reports %'] = (severe_count / total_reports * 100).round(2)

    # Lethality percentage
    metrics['Lethality %'] = (metrics['Deaths'] / total_reports * 100).round(2)

    # Hospitalization rate
    metrics['Hospitalization Rate %'] = (
        metrics['Hospitalizations'] / total_reports * 100
    ).round(2)

    # Add manufacturer if available
    if 'VAX_MANU' in data.columns:
        # Get most common manufacturer per batch
        manu_map = data.groupby('VAX_LOT')['VAX_MANU'].agg(
            lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Unknown'
        )
        metrics['Company'] = manu_map

    # Sort by adverse reaction reports (descending)
    metrics = metrics.sort_values('Adverse Reaction Reports', ascending=False)

    return metrics


def save_as_datatables_json(df: pd.DataFrame, output_path: str):
    """
    Save DataFrame in DataTables-compatible JSON format.

    Format: {"columns": [...], "data": [[...], ...]}
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Reset index to include batch code as column
    df_reset = df.reset_index()

    # Convert to orient='split' format
    data_dict = {
        'columns': df_reset.columns.tolist(),
        'data': df_reset.values.tolist()
    }

    with open(output_path, 'w') as f:
        json.dump(data_dict, f, indent=2)

    print(f"✅ Saved batch analysis to {output_path}")
    print(f"   Total batches: {len(df)}")
    print(f"   Total reports: {df['Adverse Reaction Reports'].sum():,}")


def main():
    if len(sys.argv) != 3:
        print("Usage: python batch_analyzer.py <input_csv> <output_json>")
        print("\nExample:")
        print("  python batch_analyzer.py merged_vaers.csv batchCodeTables/Global.json")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    print(f"📊 Loading data from {input_file}...")
    data = pd.read_csv(input_file, low_memory=False)

    # Validate required columns
    if 'VAX_LOT' not in data.columns:
        print("❌ Error: Input CSV must contain 'VAX_LOT' column")
        sys.exit(1)

    # Normalize batch codes
    print("🔧 Normalizing batch codes...")
    data['VAX_LOT'] = data['VAX_LOT'].str.upper().str.strip()

    # Remove blank batch codes
    data = data[data['VAX_LOT'].notna() & (data['VAX_LOT'] != '')]

    print(f"📈 Calculating batch metrics for {data['VAX_LOT'].nunique()} unique batches...")
    batch_metrics = calculate_batch_metrics(data)

    print(f"💾 Saving results...")
    save_as_datatables_json(batch_metrics, output_file)

    # Print summary statistics
    print("\n📊 Summary Statistics:")
    print(f"   Mean reports per batch: {batch_metrics['Adverse Reaction Reports'].mean():.1f}")
    print(f"   Median lethality: {batch_metrics['Lethality %'].median():.2f}%")
    print(f"   Max lethality: {batch_metrics['Lethality %'].max():.2f}%")

    # Identify high-risk batches (top 10 by lethality %)
    high_risk = batch_metrics.nlargest(10, 'Lethality %')
    print("\n⚠️  Top 10 Batches by Lethality %:")
    for batch, row in high_risk.iterrows():
        print(f"   {batch}: {row['Lethality %']:.2f}% ({row['Deaths']}/{row['Adverse Reaction Reports']} reports)")


if __name__ == '__main__':
    main()
