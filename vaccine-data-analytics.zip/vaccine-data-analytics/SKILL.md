---
name: vaccine-data-analytics
description: This skill should be used when analyzing VAERS (Vaccine Adverse Event Reporting System) data, particularly for COVID-19 vaccine batch safety surveillance. Use this skill for exploratory data analysis, batch code safety analysis, symptom frequency analysis, geographic distribution patterns, and statistical comparisons of vaccine adverse event data in CSV and JSON formats.
---

# Vaccine Data Analytics Skill

## Overview

Provide specialized tools and knowledge for analyzing VAERS (Vaccine Adverse Event Reporting System) data, with a focus on COVID-19 vaccine batch safety surveillance. This skill enables efficient analysis of large-scale adverse event datasets, including batch code safety metrics, symptom frequency distributions, geographic patterns, and time series trends.

## When to Use This Skill

Use this skill when:

- Analyzing VAERS CSV data files (VAERSDATA, VAERSVAX, VAERSSYMPTOMS)
- Calculating batch code safety metrics (deaths, disabilities, hospitalizations by batch)
- Generating symptom frequency histograms for vaccine batches
- Analyzing geographic distribution of adverse events
- Performing exploratory data analysis on vaccine safety data
- Merging multiple VAERS data sources
- Processing Google Analytics data for batch code click tracking
- Creating JSON outputs for web-based vaccine safety dashboards
- Investigating correlations between adverse events and batch codes

## Core Workflows

### 1. Batch Code Safety Analysis

**Objective:** Calculate safety metrics aggregated by vaccine batch code (VAX_LOT).

**Process:**

1. Load and merge VAERS data files using `scripts/vaers_data_merger.py`:
   ```bash
   python scripts/vaers_data_merger.py <data_dir> merged_vaers.csv
   ```

2. Run batch analysis using `scripts/batch_analyzer.py`:
   ```bash
   python scripts/batch_analyzer.py merged_vaers.csv output/batchCodeTables/Global.json
   ```

3. Review key metrics:
   - **Adverse Reaction Reports**: Total reports per batch
   - **Deaths**: Count where DIED='Y'
   - **Disabilities**: Count where DISABLE='Y'
   - **Life-Threatening Illnesses**: Count where L_THREAT='Y'
   - **Hospitalizations**: Count where HOSPITAL='Y'
   - **Severe Reports %**: Percentage of reports with severe outcomes
   - **Lethality %**: Percentage of reports resulting in death

**Output Format:** DataTables-compatible JSON (`orient='split'`) suitable for frontend rendering.

**Reference:** See `references/analysis_patterns.md` for detailed implementation patterns.

### 2. Symptom Frequency Analysis

**Objective:** Generate symptom histograms for each vaccine batch to identify common adverse reactions.

**Process:**

1. Use `scripts/symptom_histogram.py` to create per-batch histograms:
   ```bash
   python scripts/symptom_histogram.py VAERSSYMPTOMS.csv VAERSVAX.csv output/histograms/Global/
   ```

2. The script will:
   - Unpivot SYMPTOM1 through SYMPTOM5 columns
   - Group by batch code (VAX_LOT)
   - Calculate frequency counts for each symptom
   - Output one JSON file per batch code

**Output Format:** One JSON file per batch containing:
```json
{
  "batchcode": "EN6201",
  "Company": "PFIZER\\BIONTECH",
  "Adverse Reaction Reports": 2797,
  "histogram": {
    "Headache": 432,
    "Fatigue": 393,
    ...
  }
}
```

**Important Notes:**
- Symptoms use standardized MedDRA (Medical Dictionary for Regulatory Activities) terminology
- Multiple symptom columns require unpivoting for accurate frequency analysis
- Handle special characters in batch codes when creating filenames

### 3. Data Merging and Preprocessing

**Objective:** Combine VAERS data sources into a single analysis-ready DataFrame.

**Process:**

1. Ensure directory contains all three VAERS files:
   - `*VAERSDATA.csv` - Primary adverse event records
   - `*VAERSVAX.csv` - Vaccine administration details
   - `*VAERSSYMPTOMS.csv` - Coded symptoms (MedDRA terms)

2. Run merger script:
   ```bash
   python scripts/vaers_data_merger.py ./data/ merged_output.csv
   ```

3. The script automatically:
   - Filters to COVID-19 vaccines (VAX_TYPE='COVID19')
   - Normalizes batch codes to uppercase and trimmed
   - Converts binary columns (DIED, DISABLE, etc.) from Y/N to 1/0
   - Performs inner join on VAERS_ID

**Data Quality Checks:**
- Verify unique VAERS_IDs match expectations
- Check for missing batch codes (VAX_LOT)
- Validate date ranges
- Confirm binary field normalization

**Reference:** See `references/vaers_schema.md` for complete schema documentation.

### 4. Exploratory Data Analysis

**Common EDA Tasks:**

**Summary Statistics:**
```python
import pandas as pd

# Load merged data
data = pd.read_csv('merged_vaers.csv')

# Batch-level statistics
print(f"Unique batches: {data['VAX_LOT'].nunique()}")
print(f"Total reports: {len(data)}")
print(f"Date range: {data['VAX_DATE'].min()} to {data['VAX_DATE'].max()}")

# Manufacturer distribution
print(data['VAX_MANU'].value_counts())

# Adverse event rates
print(f"Deaths: {data['DIED'].sum()} ({data['DIED'].mean()*100:.2f}%)")
print(f"Hospitalizations: {data['HOSPITAL'].sum()} ({data['HOSPITAL'].mean()*100:.2f}%)")
```

**Outlier Detection:**
```python
from scipy import stats

# Calculate z-scores for lethality rates per batch
batch_stats = data.groupby('VAX_LOT').agg({
    'VAERS_ID': 'count',
    'DIED': 'sum'
})
batch_stats['lethality_rate'] = batch_stats['DIED'] / batch_stats['VAERS_ID']
batch_stats['z_score'] = stats.zscore(batch_stats['lethality_rate'])

# Flag outliers (|z| > 3)
outliers = batch_stats[abs(batch_stats['z_score']) > 3]
print(f"Outlier batches: {len(outliers)}")
```

**Missing Value Analysis:**
```python
# Check missing rates by column
missing_rates = data.isnull().sum() / len(data) * 100
print(missing_rates[missing_rates > 0].sort_values(ascending=False))
```

**Reference:** See `references/analysis_patterns.md` section "Statistical Comparisons" for advanced techniques.

### 5. Geographic Distribution Analysis

**Objective:** Analyze country-level adverse event patterns and calculate Jensen-Shannon distances.

**Key Steps:**

1. Extract country from SPLTTYPE column:
   ```python
   def extract_country(splttype):
       if pd.isna(splttype) or 'US' in str(splttype):
           return 'United States'
       # Parse country code from SPLTTYPE
       # Implementation varies based on format
       return parsed_country

   data['COUNTRY'] = data['SPLTTYPE'].apply(extract_country)
   ```

2. Calculate country distributions per batch:
   ```python
   country_counts = data.groupby(['VAX_LOT', 'COUNTRY']).size()
   country_proportions = country_counts / country_counts.groupby('VAX_LOT').sum()
   ```

3. Compute Jensen-Shannon distance to detect geographic anomalies:
   ```python
   from scipy.spatial.distance import jensenshannon

   # Compare batch distribution to global average
   global_dist = data['COUNTRY'].value_counts(normalize=True)
   batch_dist = data[data['VAX_LOT'] == 'EN6201']['COUNTRY'].value_counts(normalize=True)

   js_distance = jensenshannon(
       global_dist.reindex(batch_dist.index, fill_value=0),
       batch_dist
   )
   ```

**Interpretation:**
- JS distance near 0 = batch distribution matches global pattern
- JS distance near 1 = batch distribution differs significantly from global

**Reference:** See `references/analysis_patterns.md` section "Geographic Distribution Analysis".

### 6. Time Series Analysis

**Objective:** Track adverse event trends using Google Analytics click data.

**Process:**

1. Merge multiple Google Analytics CSV files:
   ```python
   import glob
   import pandas as pd

   ga_files = glob.glob('data/GoogleAnalytics/CountryByBatchcode *.csv')
   combined = []

   for file in ga_files:
       # Extract date range from filename
       date_range = file.split(' ')[-1].replace('.csv', '')
       df = pd.read_csv(file, skiprows=2)
       df['date_range'] = date_range
       combined.append(df)

   ga_data = pd.concat(combined, ignore_index=True)
   ```

2. Convert date ranges to datetime for trend analysis:
   ```python
   ga_data['start_date'] = pd.to_datetime(
       ga_data['date_range'].str.split('-').str[0],
       format='%Y%m%d'
   )
   ```

3. Aggregate by time period (e.g., monthly):
   ```python
   monthly_trends = ga_data.groupby([
       pd.Grouper(key='start_date', freq='M'),
       'batchcode'
   ])['clicks'].sum()
   ```

## Reusable Scripts

This skill includes production-ready scripts in `scripts/`:

### `vaers_data_merger.py`

Merge VAERSDATA, VAERSVAX, and VAERSSYMPTOMS files.

**Usage:**
```bash
python scripts/vaers_data_merger.py <data_directory> <output_csv>
```

**Features:**
- Auto-detects VAERS files with year prefixes (e.g., 2023VAERSDATA.csv)
- Filters to COVID-19 vaccines automatically
- Normalizes batch codes and binary columns
- Outputs single merged CSV

### `batch_analyzer.py`

Calculate batch-level safety metrics and output DataTables JSON.

**Usage:**
```bash
python scripts/batch_analyzer.py <merged_csv> <output_json>
```

**Features:**
- Aggregates by VAX_LOT (batch code)
- Calculates deaths, disabilities, hospitalizations
- Computes derived metrics (Severe Reports %, Lethality %)
- Outputs in frontend-compatible JSON format
- Prints summary statistics and top 10 high-risk batches

### `symptom_histogram.py`

Generate symptom frequency histograms per batch.

**Usage:**
```bash
python scripts/symptom_histogram.py <symptoms_csv> <vax_csv> <output_dir>
```

**Features:**
- Unpivots SYMPTOM1-SYMPTOM5 columns
- Creates frequency counts per batch
- Outputs one JSON file per batch code
- Sanitizes filenames to avoid special characters
- Includes manufacturer and report count metadata

## Reference Documentation

This skill includes detailed reference materials in `references/`:

### `vaers_schema.md`

Complete VAERS data schema documentation covering:
- Column definitions for VAERSDATA, VAERSVAX, VAERSSYMPTOMS
- Data normalization requirements (binary fields, batch codes, dates)
- Join patterns for merging files
- Data quality notes and performance tips
- Encoding and memory management recommendations

**When to use:** Reference this when working with raw VAERS CSV files, understanding column meanings, or debugging data quality issues.

### `analysis_patterns.md`

Common analysis patterns and implementation code for:
- Batch code safety analysis with formulas
- Symptom frequency histogram generation
- Geographic distribution and Jensen-Shannon distance
- Time series trend analysis
- Statistical comparisons and outlier detection
- Data quality checks
- Performance optimization techniques

**When to use:** Reference this when implementing new analyses, understanding calculation methodologies, or optimizing code performance.

## Important Implementation Notes

### Data Normalization Best Practices

1. **Batch Code Normalization:**
   - Always convert VAX_LOT to uppercase: `data['VAX_LOT'].str.upper()`
   - Trim whitespace: `data['VAX_LOT'].str.strip()`
   - Remove invalid batch codes (blanks, NaN)

2. **Binary Field Conversion:**
   - Convert Y/N to 1/0 for aggregation: `(data['DIED'] == 'Y').astype(int)`
   - Handle missing values as 0 (not Y = not occurred)

3. **Date Handling:**
   - Use `pd.to_datetime()` with `errors='coerce'` for inconsistent formats
   - VAERS dates are typically MM/DD/YYYY format

### File Naming Considerations

When creating output files (especially histogram JSONs):

- **Sanitize batch codes:** Remove spaces, special characters (#, %, ;)
- **Use safe filename patterns:** Replace '/' with '_', limit to alphanumeric + underscore/hyphen
- **Check Cloudflare Pages limits:** Asset count limits may require file cleanup

**Example sanitization:**
```python
safe_filename = batch_code.replace('/', '_').replace(' ', '_')
safe_filename = ''.join(c for c in safe_filename if c.isalnum() or c in ('_', '-', '.'))
```

### Performance Optimization

For large datasets (millions of rows):

1. **Filter early:** Apply VAX_TYPE=='COVID19' filter immediately after reading
2. **Use categorical dtypes:** For STATE, SEX, VAX_MANU (low-cardinality columns)
3. **Chunked processing:** Use `pd.read_csv(..., chunksize=10000)` for memory constraints
4. **Downcast numeric types:** Use `downcast='integer'` and `downcast='float'`

**Reference:** See `references/analysis_patterns.md` section "Performance Optimization" for code examples.

### JSON Output Formats

Frontend expects specific JSON formats:

**Batch Code Tables:**
```json
{
  "columns": ["VAX_LOT", "Adverse Reaction Reports", "Deaths", ...],
  "data": [["EN6201", 2797, 173, ...], ...]
}
```

**Histograms:**
```json
{
  "batchcode": "EN6201",
  "Company": "PFIZER\\BIONTECH",
  "Adverse Reaction Reports": 2797,
  "histogram": {"Headache": 432, ...}
}
```

Use `DataFrame.to_json(orient='split')` for batch tables, and custom dictionary construction for histograms.

## Workflow Integration with Existing Codebase

This skill aligns with the **s2y-batches** (HowBadIsMyBatch) project architecture:

**Pipeline Integration Points:**

1. **Data Acquisition:** VAERS files downloaded via `VAERSFileDownloader.py` (with ML captcha solving)
2. **Data Processing:** Use skill scripts or existing factory classes:
   - `BatchCodeTableFactory.py` ↔ `scripts/batch_analyzer.py`
   - `SymptomByBatchcodeTableFactory.py` ↔ `scripts/symptom_histogram.py`
3. **Output Storage:** JSON files go to `docs/data/` for frontend consumption
4. **Frontend Display:** DataTables rendering in `docs/batchCodes.html`

**When to use skill vs. existing code:**
- **Use skill scripts:** Quick analysis, prototyping, one-off investigations
- **Use factory classes:** Production pipeline, automated GitHub Actions runs, complex multi-stage processing

## Common Troubleshooting

**Issue:** "VAX_LOT column not found"
- **Solution:** Ensure VAERSVAX file is included in merge, check column name spelling

**Issue:** "Encoding errors when reading CSV"
- **Solution:** Use `encoding='iso-8859-1'` parameter in `pd.read_csv()`

**Issue:** "Out of memory errors"
- **Solution:** Use chunked processing (`chunksize` parameter) or filter to specific date ranges

**Issue:** "Histogram files have invalid names"
- **Solution:** Sanitize batch codes before creating filenames (remove spaces, special chars)

**Issue:** "Binary columns show Y/N instead of counts"
- **Solution:** Convert to numeric first: `(df['DIED'] == 'Y').astype(int)`

## Example Usage Scenarios

### Scenario 1: Analyze a Specific Batch Code

```python
import pandas as pd

# Load merged data
data = pd.read_csv('merged_vaers.csv')

# Filter to specific batch
batch_code = 'EN6201'
batch_data = data[data['VAX_LOT'] == batch_code]

# Calculate metrics
total_reports = len(batch_data)
deaths = batch_data['DIED'].sum()
hospitalizations = batch_data['HOSPITAL'].sum()

print(f"Batch: {batch_code}")
print(f"Total Reports: {total_reports}")
print(f"Deaths: {deaths} ({deaths/total_reports*100:.2f}%)")
print(f"Hospitalizations: {hospitalizations} ({hospitalizations/total_reports*100:.2f}%)")

# Top symptoms
symptom_cols = ['SYMPTOM1', 'SYMPTOM2', 'SYMPTOM3', 'SYMPTOM4', 'SYMPTOM5']
all_symptoms = batch_data[symptom_cols].values.flatten()
all_symptoms = [s for s in all_symptoms if pd.notna(s)]

from collections import Counter
top_symptoms = Counter(all_symptoms).most_common(10)
print("\nTop 10 Symptoms:")
for symptom, count in top_symptoms:
    print(f"  {symptom}: {count}")
```

### Scenario 2: Compare Multiple Manufacturers

```python
# Group by manufacturer
manu_comparison = data.groupby('VAX_MANU').agg({
    'VAERS_ID': 'count',
    'DIED': 'sum',
    'DISABLE': 'sum',
    'HOSPITAL': 'sum'
})

# Calculate rates
manu_comparison['Death Rate %'] = (
    manu_comparison['DIED'] / manu_comparison['VAERS_ID'] * 100
)

print(manu_comparison)
```

### Scenario 3: Find Batches with High Adverse Event Rates

```python
# Calculate batch-level rates
batch_rates = data.groupby('VAX_LOT').agg({
    'VAERS_ID': 'count',
    'DIED': 'sum',
    'DISABLE': 'sum'
})

batch_rates['Death Rate %'] = batch_rates['DIED'] / batch_rates['VAERS_ID'] * 100

# Filter to batches with sufficient reports (min 100)
batch_rates = batch_rates[batch_rates['VAERS_ID'] >= 100]

# Sort by death rate
high_risk_batches = batch_rates.nlargest(20, 'Death Rate %')
print(high_risk_batches)
```

## Additional Resources

- **VAERS Official Website:** https://vaers.hhs.gov/
- **MedDRA Terminology:** Medical Dictionary for Regulatory Activities (symptom coding standard)
- **Project Documentation:** See `CLAUDE.md` in repository root for full system architecture
- **Factory Classes:** See `src/` directory for production pipeline implementation
- **Frontend Code:** See `docs/*.js` for DataTables rendering and visualization

## Summary

This skill provides:
- ✅ Production-ready scripts for common VAERS analysis tasks
- ✅ Comprehensive reference documentation for data schemas and patterns
- ✅ Best practices for data normalization and performance optimization
- ✅ Integration guidance with existing project architecture
- ✅ Example code for common analysis scenarios

Use this skill whenever working with VAERS vaccine safety data to ensure consistent, efficient, and accurate analysis.
