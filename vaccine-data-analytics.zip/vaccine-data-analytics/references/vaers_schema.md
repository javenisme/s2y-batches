# VAERS Data Schema Reference

## Overview

VAERS (Vaccine Adverse Event Reporting System) data consists of three primary CSV files that must be joined for complete analysis.

## Core Data Files

### 1. VAERSDATA.csv

Primary adverse event records.

**Key Columns:**
- `VAERS_ID` - Unique report identifier (join key)
- `RECVDATE` - Date report received (MM/DD/YYYY)
- `STATE` - Two-letter state code
- `AGE_YRS` - Patient age in years (float)
- `SEX` - Patient sex (M/F/U)
- `DIED` - Death occurred (Y/N or blank)
- `DATEDIED` - Date of death (MM/DD/YYYY)
- `L_THREAT` - Life-threatening illness (Y/N or blank)
- `ER_VISIT` - Emergency room visit (Y/N or blank)
- `HOSPITAL` - Hospitalization (Y/N or blank)
- `HOSPDAYS` - Days hospitalized (integer)
- `DISABLE` - Permanent disability (Y/N or blank)
- `RECOVD` - Recovered (Y/N/U or blank)
- `VAX_DATE` - Vaccination date (MM/DD/YYYY)
- `ONSET_DATE` - Symptom onset date (MM/DD/YYYY)
- `SYMPTOM_TEXT` - Free-text symptom description
- `SPLTTYPE` - Report type (contains country code for international reports)
- `HISTORY` - Medical history (free text)
- `ALLERGIES` - Known allergies (free text)

### 2. VAERSVAX.csv

Vaccine administration details (one row per vaccine dose).

**Key Columns:**
- `VAERS_ID` - Report identifier (join key)
- `VAX_TYPE` - Vaccine type code (e.g., "COVID19")
- `VAX_MANU` - Manufacturer name (e.g., "PFIZER\\BIONTECH", "MODERNA", "JANSSEN")
- `VAX_LOT` - Batch/lot number (CRITICAL for batch analysis)
- `VAX_DOSE_SERIES` - Dose number in series (1, 2, 3, etc.)
- `VAX_ROUTE` - Administration route (IM, SC, etc.)
- `VAX_SITE` - Injection site (LA=left arm, RA=right arm, etc.)
- `VAX_NAME` - Vaccine product name

**Important Notes:**
- One VAERS_ID can have multiple rows (multiple vaccines in same visit)
- For batch analysis, filter to COVID19 vaccines only
- Batch codes should be normalized to uppercase for consistency

### 3. VAERSSYMPTOMS.csv

Coded symptoms using MedDRA terminology (one row per report).

**Key Columns:**
- `VAERS_ID` - Report identifier (join key)
- `SYMPTOM1` through `SYMPTOM5` - MedDRA symptom terms (up to 5 per report)
- `SYMPTOMVERSION1` through `SYMPTOMVERSION5` - MedDRA version codes

**Important Notes:**
- Symptoms are coded using standardized MedDRA (Medical Dictionary for Regulatory Activities) terms
- Multiple symptom columns must be "unpivoted" for frequency analysis
- Not all reports have coded symptoms (some only have SYMPTOM_TEXT)

## Data Normalization Requirements

### Binary Fields (Y/N to 1/0)

Convert these columns from Y/N strings to 1/0 integers:
- `DIED`: Y → 1, else → 0
- `DISABLE`: Y → 1, else → 0
- `L_THREAT`: Y → 1, else → 0
- `HOSPITAL`: Y → 1, else → 0
- `ER_VISIT`: Y → 1, else → 0

### Batch Codes

- Always convert `VAX_LOT` to uppercase
- Remove leading/trailing whitespace
- Handle special characters that may cause file naming issues (spaces, #, %, ;)

### Country Extraction

Extract country from `SPLTTYPE` column:
- Contains patterns like "US/Foreign" or country codes
- Map to standardized country names

## Common Joins

### Complete Dataset Join

```python
# Join all three files
vaers_data = pd.read_csv('VAERSDATA.csv', encoding='iso-8859-1', low_memory=False)
vaers_vax = pd.read_csv('VAERSVAX.csv', encoding='iso-8859-1', low_memory=False)
vaers_symptoms = pd.read_csv('VAERSSYMPTOMS.csv', encoding='iso-8859-1', low_memory=False)

# Merge VAERSDATA with VAERSVAX (one-to-many)
merged = vaers_data.merge(vaers_vax, on='VAERS_ID', how='inner')

# Optionally merge with VAERSSYMPTOMS (one-to-one)
merged = merged.merge(vaers_symptoms, on='VAERS_ID', how='left')
```

### COVID-19 Vaccine Filter

```python
# Filter to COVID-19 vaccines only
covid_data = merged[merged['VAX_TYPE'] == 'COVID19']
```

## Data Quality Notes

- **Missing Values**: Many columns contain blanks or "Unknown"
- **Encoding**: Use `encoding='iso-8859-1'` for reading CSVs
- **Memory**: Use `low_memory=False` for large files
- **Duplicates**: VAERS_ID can repeat in VAERSVAX (multiple doses)
- **Date Formats**: Inconsistent date formats require parsing with `errors='coerce'`
- **Free Text**: SYMPTOM_TEXT and HISTORY contain unstructured data requiring NLP

## Performance Tips

- Read only required columns using `usecols` parameter
- Filter early in pipeline (e.g., VAX_TYPE=='COVID19' immediately after reading)
- Use categorical dtype for low-cardinality columns (STATE, SEX, VAX_MANU)
- Consider Dask for datasets larger than available RAM
