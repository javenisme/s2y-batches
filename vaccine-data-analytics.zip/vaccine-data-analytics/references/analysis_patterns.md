# Common VAERS Data Analysis Patterns

## Batch Code Safety Analysis

### Objective
Aggregate adverse events by vaccine batch code (VAX_LOT) to identify potentially problematic batches.

### Key Metrics

**Adverse Event Counts:**
- Total reports per batch
- Deaths (`DIED == 'Y'`)
- Disabilities (`DISABLE == 'Y'`)
- Life-threatening illnesses (`L_THREAT == 'Y'`)
- Hospitalizations (`HOSPITAL == 'Y'`)

**Derived Metrics:**
- **Severe Reports %**: `(Deaths + Disabilities + L_THREAT + Hospitalizations) / Total Reports * 100`
- **Lethality %**: `Deaths / Total Reports * 100`
- **Hospitalization Rate**: `Hospitalizations / Total Reports * 100`

### Implementation Pattern

```python
# Group by batch code and aggregate
batch_analysis = covid_data.groupby('VAX_LOT').agg({
    'VAERS_ID': 'count',  # Total reports
    'DIED': lambda x: (x == 'Y').sum(),
    'DISABLE': lambda x: (x == 'Y').sum(),
    'L_THREAT': lambda x: (x == 'Y').sum(),
    'HOSPITAL': lambda x: (x == 'Y').sum()
}).rename(columns={
    'VAERS_ID': 'Adverse Reaction Reports',
    'DIED': 'Deaths',
    'DISABLE': 'Disabilities',
    'L_THREAT': 'Life-Threatening Illnesses',
    'HOSPITAL': 'Hospitalizations'
})

# Calculate percentages
batch_analysis['Severe Reports %'] = (
    (batch_analysis['Deaths'] +
     batch_analysis['Disabilities'] +
     batch_analysis['Life-Threatening Illnesses'] +
     batch_analysis['Hospitalizations']) /
    batch_analysis['Adverse Reaction Reports'] * 100
)

batch_analysis['Lethality %'] = (
    batch_analysis['Deaths'] /
    batch_analysis['Adverse Reaction Reports'] * 100
)
```

### Output Format

Save as JSON in DataTables `orient='split'` format:

```python
batch_analysis.reset_index().to_json(
    'batchCodeTables/Global.json',
    orient='split',
    index=False
)
```

## Symptom Frequency Analysis

### Objective
Create histograms of symptom frequencies for each batch code to identify common adverse reactions.

### Data Preparation

**Unpivot Symptoms:**
```python
# Melt SYMPTOM1 through SYMPTOM5 into single column
symptom_cols = ['SYMPTOM1', 'SYMPTOM2', 'SYMPTOM3', 'SYMPTOM4', 'SYMPTOM5']
symptoms_long = vaers_symptoms.melt(
    id_vars=['VAERS_ID'],
    value_vars=symptom_cols,
    var_name='symptom_column',
    value_name='symptom'
).dropna(subset=['symptom'])
```

**Join with Batch Data:**
```python
# Merge with vaccine data to get batch codes
symptom_batch = symptoms_long.merge(
    covid_vax[['VAERS_ID', 'VAX_LOT']],
    on='VAERS_ID'
)
```

### Histogram Generation

```python
# Create symptom frequency histogram per batch
histograms = symptom_batch.groupby(['VAX_LOT', 'symptom']).size().reset_index(name='count')

# Pivot to dictionary format
for batch_code in histograms['VAX_LOT'].unique():
    batch_hist = histograms[histograms['VAX_LOT'] == batch_code]
    histogram_dict = dict(zip(batch_hist['symptom'], batch_hist['count']))

    # Save as JSON
    output = {
        'batchcode': batch_code,
        'histogram': histogram_dict
    }
    # Save to data/histograms/Global/{batch_code}.json
```

### Output Format

One JSON file per batch code in `data/histograms/Global/`:

```json
{
  "batchcode": "EN6201",
  "Company": "PFIZER\\BIONTECH",
  "Adverse Reaction Reports": 2797,
  "Deaths": 173,
  "histogram": {
    "Headache": 432,
    "Fatigue": 393,
    "Chills": 313,
    ...
  }
}
```

## Geographic Distribution Analysis

### Objective
Analyze geographic patterns of adverse events and calculate Jensen-Shannon distance to detect unusual distributions.

### Country Extraction

```python
# Extract country from SPLTTYPE column
def extract_country(splttype):
    if pd.isna(splttype):
        return 'United States'
    if 'Foreign' in str(splttype):
        # Parse country code or name from SPLTTYPE
        # Implementation varies based on format
        pass
    return 'United States'

data['COUNTRY'] = data['SPLTTYPE'].apply(extract_country)
```

### Country Counts by Batch

```python
# Count reports by country for each batch
country_counts = data.groupby(['VAX_LOT', 'COUNTRY']).size().reset_index(name='count')

# Convert to distribution (proportions)
batch_totals = country_counts.groupby('VAX_LOT')['count'].sum()
country_counts['proportion'] = country_counts.apply(
    lambda row: row['count'] / batch_totals[row['VAX_LOT']],
    axis=1
)
```

### Jensen-Shannon Distance

```python
from scipy.spatial.distance import jensenshannon

def calculate_js_distance(batch_dist, reference_dist):
    """
    Calculate Jensen-Shannon distance between batch distribution
    and reference distribution (e.g., global average).

    Returns value between 0 (identical) and 1 (completely different).
    """
    # Align distributions to same countries
    all_countries = set(batch_dist.keys()) | set(reference_dist.keys())

    p = [batch_dist.get(c, 0) for c in all_countries]
    q = [reference_dist.get(c, 0) for c in all_countries]

    return jensenshannon(p, q)
```

## Time Series Analysis

### Objective
Track adverse event trends over time using Google Analytics click data.

### Merge Multiple CSV Files

```python
import glob

# Read all Google Analytics CSV files
ga_files = glob.glob('data/GoogleAnalytics/CountryByBatchcode *.csv')

ga_data = []
for file in ga_files:
    # Extract date range from filename
    # "CountryByBatchcode 20230302-20230430.csv"
    date_range = file.split(' ')[-1].replace('.csv', '')

    df = pd.read_csv(file, skiprows=2)  # Skip header rows
    df['date_range'] = date_range
    ga_data.append(df)

combined_ga = pd.concat(ga_data, ignore_index=True)
```

### Trend Analysis

```python
# Convert date ranges to datetime
combined_ga['start_date'] = pd.to_datetime(
    combined_ga['date_range'].str.split('-').str[0],
    format='%Y%m%d'
)

# Aggregate by month
monthly_trends = combined_ga.groupby([
    pd.Grouper(key='start_date', freq='M'),
    'batchcode'
])['clicks'].sum()
```

## Statistical Comparisons

### Outlier Detection

Identify batches with unusually high adverse event rates using statistical methods:

```python
from scipy import stats

# Calculate z-scores for lethality rates
batch_analysis['lethality_zscore'] = stats.zscore(batch_analysis['Lethality %'])

# Flag outliers (|z| > 3)
outliers = batch_analysis[abs(batch_analysis['lethality_zscore']) > 3]
```

### Correlation Analysis

```python
# Correlation between different adverse event types
correlation_matrix = batch_analysis[[
    'Deaths',
    'Disabilities',
    'Life-Threatening Illnesses',
    'Hospitalizations'
]].corr()
```

## Data Quality Checks

### Missing Value Analysis

```python
# Check missing rates by column
missing_rates = data.isnull().sum() / len(data) * 100
print(missing_rates[missing_rates > 0].sort_values(ascending=False))
```

### Duplicate Detection

```python
# Check for duplicate VAERS_IDs in merged data
# (Should only occur due to multiple vaccines per report)
duplicates = data[data.duplicated('VAERS_ID', keep=False)]
print(f"Duplicate reports: {duplicates['VAERS_ID'].nunique()}")
```

### Batch Code Validation

```python
# Identify invalid batch codes
invalid_batches = batch_analysis[
    batch_analysis['Adverse Reaction Reports'] < 10  # Too few reports
].index.tolist()

# Check for special characters that cause file naming issues
import re
problematic_batches = [
    batch for batch in batch_analysis.index
    if re.search(r'[#%;\ ]', batch)
]
```

## Performance Optimization

### Memory Reduction

```python
# Use categorical types for low-cardinality columns
categorical_cols = ['STATE', 'SEX', 'VAX_TYPE', 'VAX_MANU', 'COUNTRY']
for col in categorical_cols:
    if col in data.columns:
        data[col] = data[col].astype('category')

# Downcast numeric types
for col in data.select_dtypes(include=['float64']).columns:
    data[col] = pd.to_numeric(data[col], downcast='float')

for col in data.select_dtypes(include=['int64']).columns:
    data[col] = pd.to_numeric(data[col], downcast='integer')
```

### Chunked Processing

```python
# Process large files in chunks
chunk_results = []
for chunk in pd.read_csv('VAERSDATA.csv', chunksize=10000):
    # Filter and process chunk
    chunk = chunk[chunk['VAX_TYPE'] == 'COVID19']
    chunk_results.append(chunk)

data = pd.concat(chunk_results, ignore_index=True)
```
